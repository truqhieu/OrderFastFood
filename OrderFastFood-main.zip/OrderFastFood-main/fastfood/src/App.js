  import { Container } from "react-bootstrap";
  import { BrowserRouter, Route, Routes } from "react-router-dom";
 import Home from "./components/Home";
  function App() {
    return(
    <BrowserRouter>
      <Container>
      <Routes>
        <Route path="/" element={<Home />}/> 
      </Routes>
      </Container>
    </BrowserRouter>
    );
  }

  export default App;
